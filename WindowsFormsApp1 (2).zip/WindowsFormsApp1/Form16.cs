﻿using Oracle.ManagedDataAccess.Client;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Form16 : Form
    {
        public Form16()
        {
            InitializeComponent();
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form12 form12 = new Form12();
            form12.ShowDialog();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            // Check if the user is logged in
            if (!SessionManager.IsLoggedIn())
            {
                // Prompt the user with a choice to log in
                DialogResult result = MessageBox.Show(
                    "You must be logged in to buy products. Would you like to log in now?",
                    "Login Required",
                    MessageBoxButtons.YesNo,
                    MessageBoxIcon.Question
                );

                if (result == DialogResult.Yes)
                {
                    // Redirect the user to the login form
                    this.Hide();
                    Form2 loginForm = new Form2();
                    loginForm.ShowDialog();

                    // Recheck if the user is logged in after returning from login form
                    if (SessionManager.IsLoggedIn())
                    {
                        MessageBox.Show("You are now logged in. Please proceed with your purchase.", "Login Successful", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                    else
                    {
                        // User did not log in
                        MessageBox.Show("You must log in to proceed.", "Action Required", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        this.Show(); // Re-show the current form
                    }
                }
                else
                {
                    // User chose not to log in
                    MessageBox.Show("You must log in to proceed.", "Action Required", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
                return;
            }

            // User is logged in, proceed with adding the product to the cart
            int productID = 8;  // Assuming Washing Machine has ID 1
            int quantity = 1;   // Default quantity

            AddToCart(SessionManager.LoggedInUserID.Value, productID, quantity);
            // User is logged in, proceed with the purchase
            this.Hide();
            Form22 form22 = new Form22();
            form22.ShowDialog();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            // Check if the user is logged in
            if (!SessionManager.IsLoggedIn())
            {
                // Prompt the user with a choice to log in
                DialogResult result = MessageBox.Show(
                    "You must be logged in to add products to the cart. Would you like to log in now?",
                    "Login Required",
                    MessageBoxButtons.YesNo,
                    MessageBoxIcon.Question
                );

                if (result == DialogResult.Yes)
                {
                    // Redirect the user to the login form
                    this.Hide();
                    Form2 loginForm = new Form2();
                    loginForm.ShowDialog();

                    // Recheck if the user is logged in after returning from the login form
                    if (SessionManager.IsLoggedIn())
                    {
                        MessageBox.Show("You are now logged in. You can add the product to your cart.", "Login Successful", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                    else
                    {
                        // User did not log in
                        MessageBox.Show("You must log in to add products to the cart.", "Action Required", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        this.Show(); // Re-show the current form
                    }
                }
                else
                {
                    // User chose not to log in
                    MessageBox.Show("You must log in to add products to the cart.", "Action Required", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
                return;
            }

            // User is logged in, proceed with adding the product to the cart
            int productID = 8;  // Assuming Washing Machine has ID 1
            int quantity = 1;   // Default quantity

            AddToCart(SessionManager.LoggedInUserID.Value, productID, quantity);

            MessageBox.Show("Washing Machine added to cart!");

        }
        private void AddToCart(int userID, int productID, int quantity)
        {
            // Step 1: Do not check if the product is already in the cart.
            // We always add the product as a new entry, even if it's already in the cart.

            string insertQuery = "INSERT INTO CART (CART_ID, USER_ID, PRODUCT_ID, QUANTITY, PRICE) " +
                                 "VALUES (cart_seq.NEXTVAL, :userID, :productID, :quantity, " +
                                 "(SELECT PRICE FROM PRODUCTS WHERE PRODUCT_ID = :productID))";

            string conStr = @"DATA SOURCE=localhost:1521/XE; USER ID=MIAN123; PASSWORD=112233";

            using (OracleConnection conn = new OracleConnection(conStr))
            {
                conn.Open();
                using (OracleCommand insertCmd = new OracleCommand(insertQuery, conn))
                {
                    insertCmd.Parameters.Add("userID", OracleDbType.Int32).Value = userID;
                    insertCmd.Parameters.Add("productID", OracleDbType.Int32).Value = productID;
                    insertCmd.Parameters.Add("quantity", OracleDbType.Int32).Value = quantity;

                    insertCmd.ExecuteNonQuery();
                }

                MessageBox.Show("Product added to the cart!");
            }
        }

        private void Form16_Load(object sender, EventArgs e)
        {

        }
    }
}
