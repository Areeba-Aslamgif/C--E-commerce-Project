﻿using Oracle.ManagedDataAccess.Client;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Form6 : Form
    {

        public Form6()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (comboBox1.SelectedIndex ==0){
                this.Hide();
                Form7 form7 = new Form7();  
                form7.ShowDialog();
            }
            if (comboBox1.SelectedIndex == 1)
            {
                this.Hide();
                Form12 form7 = new Form12();
                form7.ShowDialog();
            }
            if (comboBox1.SelectedIndex == 2)
            {
                this.Hide();
                Form17 form7 = new Form17();
                form7.ShowDialog();
            }
        }

        private void Form6_Load(object sender, EventArgs e)
        {
            // Check if the user is logged in
            if (SessionManager.IsLoggedIn())
            {
                // Show the cart button if the user is logged in
                button1.Visible = true;  // Show the cart button
                button2.Visible = true;
                button3.Visible = true;
            }
            else
            {
                // Hide the cart button if the user is not logged in
                button1.Visible = false; // Hide the cart button
                button2.Visible = false;
                button3.Visible = false;
            }
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form1 form1 = new Form1();
            form1.ShowDialog();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (!SessionManager.IsLoggedIn())
            {
                MessageBox.Show("Please log in to view your cart.");
                return;
            }

            // Navigate to the cart page
            this.Hide();
            Form22 form22 = new Form22();
            form22.ShowDialog();

        }

        private void button2_Click(object sender, EventArgs e)
        {
            // Log out the user by clearing the session
            SessionManager.Logout();

            // Show a message to the user
            MessageBox.Show("You have been logged out successfully.", "Logout", MessageBoxButtons.OK, MessageBoxIcon.Information);

            // Redirect the user to the login page (or any other appropriate page)
            this.Hide();
            Form1 loginForm = new Form1(); // Assuming Form1 is the login page
            loginForm.ShowDialog();

            // Close the current form
            this.Close();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Hide();
            AccountSettingsForm form = new AccountSettingsForm();
            form.Show();
        }
    }
}

