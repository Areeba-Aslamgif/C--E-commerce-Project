﻿using Oracle.ManagedDataAccess.Client;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class AccountSettingsForm : Form
    {
        public AccountSettingsForm()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            // Confirm deletion
            DialogResult result = MessageBox.Show(
                "Are you sure you want to delete your account? This action cannot be undone.",
                "Delete Account",
                MessageBoxButtons.YesNo,
                MessageBoxIcon.Warning
            );

            if (result == DialogResult.Yes)
            {
                // Logic to delete the account
                DeleteAccount();
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            // Open the update account form (Form26)
            this.Hide();
            Form updateForm = new Form26();
            updateForm.ShowDialog();
            this.Show(); // Show the current form again after Form26 is closed

        }

        private void button4_Click(object sender, EventArgs e)
        {
            MessageBox.Show(
                "Returning to the main settings menu.",
                "Information",
                MessageBoxButtons.OK,
                MessageBoxIcon.Information
);

            // Navigate back to Form6
            this.Hide();
            Form6 mainForm = new Form6();
            mainForm.ShowDialog();

        }
        // Delete Account Logic
        private void DeleteAccount()
        {
            if (!SessionManager.IsLoggedIn())
            {
                MessageBox.Show("You must be logged in to delete your account.");
                return;
            }

            int userID = SessionManager.LoggedInUserID.Value;
            string conStr = @"DATA SOURCE=localhost:1521/XE; USER ID=MIAN123; PASSWORD=112233";

            using (OracleConnection conn = new OracleConnection(conStr))
            {
                conn.Open();

                // Delete from ORDERS
                string deleteOrdersQuery = "DELETE FROM ORDERS WHERE USER_ID = :userID";
                using (OracleCommand ordersCmd = new OracleCommand(deleteOrdersQuery, conn))
                {
                    ordersCmd.Parameters.Add("userID", OracleDbType.Int32).Value = userID;
                    ordersCmd.ExecuteNonQuery();
                }
                // Delete from CART
                string deleteCartQuery = "DELETE FROM CART WHERE USER_ID = :userID";
                using (OracleCommand cartCmd = new OracleCommand(deleteCartQuery, conn))
                {
                    cartCmd.Parameters.Add("userID", OracleDbType.Int32).Value = userID;
                    cartCmd.ExecuteNonQuery();
                }

                // Delete from CUSTOMER
                string deleteCustomerQuery = "DELETE FROM CUSTOMER WHERE USER_ID = :userID";
                using (OracleCommand customerCmd = new OracleCommand(deleteCustomerQuery, conn))
                {
                    customerCmd.Parameters.Add("userID", OracleDbType.Int32).Value = userID;
                    int rowsAffected = customerCmd.ExecuteNonQuery();

                    if (rowsAffected > 0)
                    {
                        MessageBox.Show(
                            "Your account and related data have been deleted successfully.",
                            "Account Deleted",
                            MessageBoxButtons.OK,
                            MessageBoxIcon.Information
                        );
                        SessionManager.Logout();
                        this.Hide();
                        Form1 loginForm = new Form1();
                        loginForm.ShowDialog();
                        this.Close();
                    }
                    else
                    {
                        MessageBox.Show(
                            "Failed to delete your account. Please try again.",
                            "Error",
                            MessageBoxButtons.OK,
                            MessageBoxIcon.Error
                        );
                    }
                }
            }

        }

    }
}
