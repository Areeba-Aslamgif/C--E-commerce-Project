﻿using Oracle.ManagedDataAccess.Client;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Form4 : Form
    {
        public Form4()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox1.Checked) { 
            textBox2.UseSystemPasswordChar= true;
                //if (textBox3.ToString() != textBox2.ToString())
                //{
                //    MessageBox.Show("Password does not match");
                //}
                //else
                //{
                //    MessageBox.Show("Password succesfull");
                //}
            }
            else
            {
                textBox2.UseSystemPasswordChar = false;
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string username = textBox1.Text;
            string password = textBox2.Text;

            string confirmPassword = textBox3.Text;

            // Validate input fields
            if (string.IsNullOrEmpty(username) || string.IsNullOrEmpty(password) || string.IsNullOrEmpty(confirmPassword))
            {
                MessageBox.Show("All fields are required.");
                return;
            }

            if (password != confirmPassword)
            {
                MessageBox.Show("Passwords do not match.");
                return;
            }

            if (!IsUsernameUnique(username))
            {
                MessageBox.Show("Username already exists. Please choose a different username.");
                return;
            }

            // Save username and password globally
            GlobalData.Username = username;
            GlobalData.Password = password;

            // Navigate to Form5
            this.Hide();
            Form5 form5 = new Form5();
            form5.ShowDialog();

        }
        private bool IsUsernameUnique(string username)
        {
            string query = "SELECT user_name FROM Customer WHERE UPPER(user_name) = UPPER(:username)";
            string conStr = @"DATA SOURCE = localhost:1521/XE; USER ID=MIAN123; PASSWORD=112233";
            try
            {
                using (OracleConnection conn = new OracleConnection(conStr))
                {
                    conn.Open();
                    using (OracleCommand cmd = new OracleCommand(query, conn))
                    {
                        cmd.Parameters.Add("username", OracleDbType.Varchar2).Value = username;
                        int count = Convert.ToInt32(cmd.ExecuteScalar());
                        return count == 0; // Returns true if no records found
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error checking username uniqueness: " + ex.Message);
                return false;
            }
        }

 
        private void pictureBox2_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form3 form3 = new Form3();
            form3.ShowDialog();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }

        private void Form4_Load(object sender, EventArgs e)
        {

        }

    }
}
