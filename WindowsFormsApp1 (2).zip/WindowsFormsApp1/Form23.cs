﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Oracle.ManagedDataAccess.Client;  // Required for Oracle DB connection

namespace WindowsFormsApp1
{
    public partial class Form23 : Form
    {
        public Form23()
        {
            InitializeComponent();
        }

        private void checkedListBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            // Ensure that a valid payment method is selected
            if (comboBox1.SelectedIndex == -1)
            {
                MessageBox.Show("Please select a valid payment method.");
                return;
            }

            // Get the selected payment method
            string paymentMethod = comboBox1.SelectedItem.ToString();

            // If "Credit Card" is selected, open Form24 to take credit card details
            if (paymentMethod == "Credit Card")
            {
                this.Hide(); // Hide the current form (Form23)

                // Create a new instance of Form24
                Form24 form24 = new Form24();

                // Show Form24 and wait for it to close
                DialogResult result = form24.ShowDialog();

                // After Form24 closes, check the result and perform necessary actions
                if (result == DialogResult.OK)
                {
                    // Handle successful processing of credit card details
                    MessageBox.Show("Credit card details processed successfully.");
                }
                else
                {
                    // Optionally handle cancelation or no action
                    MessageBox.Show("Credit card details were not processed.");
                }

                // Optionally show Form23 again (if needed), but ensure comboBox1 still has the selected value
                this.Show();
            }
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form22 form22 = new Form22();
            form22.ShowDialog();
        }

        private void PlaceOrder()
        {
            // Retrieve necessary information such as User ID from the session
            int userID = SessionManager.LoggedInUserID.Value;  // Assuming user is logged in and UserID is stored

            // Retrieve the cart ID for the logged-in user
            int cartID = GetCartID(userID);
            if (cartID == -1)
            {
                MessageBox.Show("No cart found for the logged-in user.");
                return;
            }

            // Calculate the total price of the order (you may need to fetch the cart details to calculate this)
            decimal totalPrice = CalculateTotalPrice(cartID);

            if (totalPrice <= 0)
            {
                MessageBox.Show("The total price of the order is invalid.");
                return;
            }

            // Get the selected payment method
            string paymentMethod = comboBox1.SelectedItem.ToString();

            // Insert the order details into the ORDERS table
            string query = @"
        INSERT INTO ORDERS (ORDER_ID, USER_ID, CART_ID, ORDER_DATE, STATUS, TOTAL_PRICE, PAYMENT_METHOD)
        VALUES (ORDER_SEQ.NEXTVAL, :userID, :cartID, SYSDATE, 'Pending', :totalPrice, :paymentMethod)";

            string conStr = @"DATA SOURCE=localhost:1521/XE; USER ID=MIAN123; PASSWORD=112233";  // Connection string to the database

            using (OracleConnection conn = new OracleConnection(conStr))
            {
                try
                {
                    conn.Open();
                    using (OracleCommand cmd = new OracleCommand(query, conn))
                    {
                        cmd.Parameters.Add("userID", OracleDbType.Int32).Value = userID;
                        cmd.Parameters.Add("cartID", OracleDbType.Int32).Value = cartID;
                        cmd.Parameters.Add("totalPrice", OracleDbType.Decimal).Value = totalPrice;
                        cmd.Parameters.Add("paymentMethod", OracleDbType.Varchar2).Value = paymentMethod; // Add payment method to the query

                        int rowsInserted = cmd.ExecuteNonQuery();
                        if (rowsInserted > 0)
                        {
                            MessageBox.Show("Your order has been placed successfully!");
                            // You can add logic to close the form or navigate to another page.
                        }
                        else
                        {
                            MessageBox.Show("Failed to place the order. Please try again.");
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("An error occurred while placing the order: " + ex.Message);
                }
            }
        }


        private int GetCartID(int userID)
        {
            // Query to get the cart ID based on the logged-in user
            string query = "SELECT CART_ID FROM CART WHERE USER_ID = :userID AND STATUS = 'Pending'"; // Assuming 'Active' status for active cart

            int cartID = -1; // Default value if no cart is found
            string conStr = @"DATA SOURCE=localhost:1521/XE; USER ID=MIAN123; PASSWORD=112233";  // Connection string to the database

            using (OracleConnection conn = new OracleConnection(conStr))
            {
                try
                {
                    conn.Open();
                    using (OracleCommand cmd = new OracleCommand(query, conn))
                    {
                        cmd.Parameters.Add("userID", OracleDbType.Int32).Value = userID;

                        // Execute the query and retrieve the cart ID
                        object result = cmd.ExecuteScalar();
                        if (result != DBNull.Value)
                        {
                            cartID = Convert.ToInt32(result);
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("An error occurred while retrieving the cart ID: " + ex.Message);
                }
            }

            return cartID;
        }

        private decimal CalculateTotalPrice(int cartID)
        {
            decimal totalPrice = 0;
            string query = "SELECT SUM(PRICE * QUANTITY) FROM CART WHERE CART_ID = :cartID";

            string conStr = @"DATA SOURCE=localhost:1521/XE; USER ID=MIAN123; PASSWORD=112233";

            using (OracleConnection conn = new OracleConnection(conStr))
            {
                try
                {
                    conn.Open();
                    using (OracleCommand cmd = new OracleCommand(query, conn))
                    {
                        cmd.Parameters.Add("cartID", OracleDbType.Int32).Value = cartID;

                        object result = cmd.ExecuteScalar();
                        if (result != DBNull.Value)
                        {
                            totalPrice = Convert.ToDecimal(result);
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("An error occurred while calculating the total price: " + ex.Message);
                }
            }

            return totalPrice;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            // Check if a valid payment method is selected
            if (comboBox1.SelectedIndex == -1)
            {
                MessageBox.Show("Please select a valid payment method.");
                return;
            }

            // For other payment methods (e.g., cash on delivery), proceed with placing the order
            PlaceOrder();
        }

        private void Form23_Load(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
