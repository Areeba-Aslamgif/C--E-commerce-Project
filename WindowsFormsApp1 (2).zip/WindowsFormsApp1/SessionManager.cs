﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WindowsFormsApp1
{
    public static class SessionManager
    {
        // Stores the current logged-in user's ID and username
        public static int? LoggedInUserID { get; set; }
        public static string LoggedInUserName { get; set; }

        // Method to check if the user is logged in
        public static bool IsLoggedIn()
        {
            return LoggedInUserID.HasValue;
        }

        // Method to log in the user
        public static void Login(int userID, string userName)
        {
            LoggedInUserID = userID;
            LoggedInUserName = userName;
        }

        // Method to log out the user
        public static void Logout()
        {
            LoggedInUserID = null;
            LoggedInUserName = null;
        }
    }

}
