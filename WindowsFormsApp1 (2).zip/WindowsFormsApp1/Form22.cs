﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Oracle.ManagedDataAccess.Client; // Required for Oracle DB connection

namespace WindowsFormsApp1
{
    public partial class Form22 : Form
    {
        private int selectedCartID = -1; // Variable to store the selected CART_ID
        public Form22()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form23 form23 = new Form23();
            form23.ShowDialog();
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form6 form6 = new Form6();
            form6.ShowDialog();
        }

        private void Form22_Load(object sender, EventArgs e)
        {
            // Load cart data for the logged-in user
            if (SessionManager.IsLoggedIn())
            {
                LoadCartData(SessionManager.LoggedInUserID.Value);
            }
            else
            {
                MessageBox.Show("You must be logged in to view the cart.");
                this.Close();
            }
        }

        private void LoadCartData(int userID)
        {
            string query = @"
                SELECT 
                    CART_ID, 
                    PRODUCT_ID, 
                    QUANTITY, 
                    PRICE, 
                    STATUS 
                FROM CART 
                WHERE USER_ID = :userID";

            string conStr = @"DATA SOURCE=localhost:1521/XE; USER ID=MIAN123; PASSWORD=112233";

            using (OracleConnection conn = new OracleConnection(conStr))
            {
                try
                {
                    conn.Open();
                    using (OracleCommand cmd = new OracleCommand(query, conn))
                    {
                        cmd.Parameters.Add("userID", OracleDbType.Int32).Value = userID;

                        using (OracleDataAdapter adapter = new OracleDataAdapter(cmd))
                        {
                            DataTable cartTable = new DataTable();
                            adapter.Fill(cartTable);

                            // Bind the DataTable to the DataGridView
                            dataGridView1.DataSource = cartTable;
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("An error occurred while loading the cart: " + ex.Message);
                }
            }
        }


        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void dateTimePicker1_ValueChanged(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {
            
        }

        private void button3_Click(object sender, EventArgs e)
        {
            // Ensure a row is selected when updating the quantity
            if (dataGridView1.SelectedRows.Count > 0)
            {
                // Retrieve the selected row's data
                DataGridViewRow selectedRow = dataGridView1.SelectedRows[0];

                // Get the CART_ID from the selected row
                selectedCartID = Convert.ToInt32(selectedRow.Cells["CART_ID"].Value);

                // Validate the quantity entered by the user
                if (!int.TryParse(textBox1.Text, out int newQuantity) || newQuantity <= 0)
                {
                    MessageBox.Show("Please enter a valid quantity greater than 0.");
                    return;
                }

                // Update the cart quantity in the database
                UpdateCartQuantity(selectedCartID, newQuantity);
            }
            else
            {
                MessageBox.Show("Please select a product from the cart.");
            }
        }
        private void UpdateCartQuantity(int cartID, int newQuantity)
        {
            string query = "UPDATE CART SET QUANTITY = :newQuantity WHERE CART_ID = :cartID";
            string conStr = @"DATA SOURCE=localhost:1521/XE; USER ID=MIAN123; PASSWORD=112233";

            using (OracleConnection conn = new OracleConnection(conStr))
            {
                try
                {
                    conn.Open();
                    using (OracleCommand cmd = new OracleCommand(query, conn))
                    {
                        cmd.Parameters.Add("newQuantity", OracleDbType.Int32).Value = newQuantity;
                        cmd.Parameters.Add("cartID", OracleDbType.Int32).Value = cartID;

                        int rowsUpdated = cmd.ExecuteNonQuery();
                        if (rowsUpdated > 0)
                        {
                            MessageBox.Show("Quantity updated successfully!");
                            LoadCartData(SessionManager.LoggedInUserID.Value); // Refresh DataGridView immediately
                        }
                        else
                        {
                            MessageBox.Show("Failed to update quantity. Please try again.");
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("An error occurred while updating the quantity: " + ex.Message);
                }
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            // Ensure a row is selected
            if (dataGridView1.SelectedRows.Count > 0)
            {
                // Retrieve the selected row's data
                DataGridViewRow selectedRow = dataGridView1.SelectedRows[0];

                // Get the CART_ID from the selected row
                selectedCartID = Convert.ToInt32(selectedRow.Cells["CART_ID"].Value);

                // Check if the order is placed
                if (IsOrderPlaced(selectedCartID))
                {
                    // Cancel the order
                    if (CancelOrder(selectedCartID))
                    {
                        MessageBox.Show("Order has been successfully canceled.");
                    }
                    else
                    {
                        MessageBox.Show("Failed to cancel the order. Please try again.");
                    }
                }
                else
                {
                    MessageBox.Show("The order has not been placed yet.");
                }
            }
            else
            {
                MessageBox.Show("Please select a product from the cart.");
            }
        }

        private bool IsOrderPlaced(int cartID)
        {
            string query = "SELECT COUNT(*) FROM ORDERS WHERE CART_ID = :cartID";
            string conStr = @"DATA SOURCE=localhost:1521/XE; USER ID=MIAN123; PASSWORD=112233";

            using (OracleConnection conn = new OracleConnection(conStr))
            {
                try
                {
                    conn.Open();
                    using (OracleCommand cmd = new OracleCommand(query, conn))
                    {
                        cmd.Parameters.Add("cartID", OracleDbType.Int32).Value = cartID;

                        int count = Convert.ToInt32(cmd.ExecuteScalar());
                        return count > 0; // Order exists if count > 0
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("An error occurred while checking the order: " + ex.Message);
                    return false;
                }
            }
        }

        private bool CancelOrder(int cartID)
        {
            string updateOrderQuery = "UPDATE ORDERS SET STATUS = 'Canceled by Customer' WHERE CART_ID = :cartID";
            string updateCartQuery = "UPDATE CART SET STATUS = 'Canceled' WHERE CART_ID = :cartID";
            string conStr = @"DATA SOURCE=localhost:1521/XE; USER ID=MIAN123; PASSWORD=112233";

            using (OracleConnection conn = new OracleConnection(conStr))
            {
                try
                {
                    conn.Open();

                    // Start a transaction
                    using (OracleTransaction transaction = conn.BeginTransaction())
                    {
                        try
                        {
                            // Update the order status
                            using (OracleCommand updateOrderCmd = new OracleCommand(updateOrderQuery, conn))
                            {
                                updateOrderCmd.Transaction = transaction;
                                updateOrderCmd.Parameters.Add("cartID", OracleDbType.Int32).Value = cartID;
                                updateOrderCmd.ExecuteNonQuery();
                            }

                            // Update the cart status
                            using (OracleCommand updateCartCmd = new OracleCommand(updateCartQuery, conn))
                            {
                                updateCartCmd.Transaction = transaction;
                                updateCartCmd.Parameters.Add("cartID", OracleDbType.Int32).Value = cartID;
                                updateCartCmd.ExecuteNonQuery();
                            }

                            // Commit the transaction
                            transaction.Commit();

                            MessageBox.Show("Order has been successfully canceled.");
                            LoadCartData(SessionManager.LoggedInUserID.Value); // Refresh DataGridView immediately
                            return true; // Indicate success
                        }
                        catch
                        {
                            // Rollback the transaction in case of any failure
                            transaction.Rollback();
                            throw;
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("An error occurred while canceling the order: " + ex.Message);
                    return false;
                }
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            // Ensure a row is selected
            if (dataGridView1.SelectedRows.Count > 0)
            {
                // Retrieve the selected row's data
                DataGridViewRow selectedRow = dataGridView1.SelectedRows[0];

                // Get the CART_ID from the selected row
                int cartID = Convert.ToInt32(selectedRow.Cells["CART_ID"].Value);

                // Check the product status before deletion
                string status = GetProductStatus(cartID);

                if (status == "Processed" || status == "Shipped")
                {
                    MessageBox.Show("You cannot delete this product because its status is 'Processed' or 'Shipped'. Please cancel the order first.");
                }
                else
                {
                    // Proceed with deleting the product from both the CART and ORDERS tables
                    if (DeleteProductFromCart(cartID))
                    {
                        MessageBox.Show("Product has been successfully deleted from the cart and orders.");
                        LoadCartData(SessionManager.LoggedInUserID.Value); // Refresh DataGridView immediately
                    }
                    else
                    {
                        MessageBox.Show("Failed to delete the product. Please try again.");
                    }
                }
            }
            else
            {
                MessageBox.Show("Please select a product from the cart.");
            }
        }
        private string GetProductStatus(int cartID)
        {
            string query = "SELECT STATUS FROM CART WHERE CART_ID = :cartID";
            string status = string.Empty;
            string conStr = @"DATA SOURCE=localhost:1521/XE; USER ID=MIAN123; PASSWORD=112233";

            using (OracleConnection conn = new OracleConnection(conStr))
            {
                try
                {
                    conn.Open();
                    using (OracleCommand cmd = new OracleCommand(query, conn))
                    {
                        cmd.Parameters.Add("cartID", OracleDbType.Int32).Value = cartID;
                        object result = cmd.ExecuteScalar();
                        if (result != DBNull.Value)
                        {
                            status = result.ToString();
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("An error occurred while retrieving the product status: " + ex.Message);
                }
            }
            return status;
        }

        private bool DeleteProductFromCart(int cartID)
        {
            string deleteOrderQuery = "DELETE FROM ORDERS WHERE CART_ID = :cartID";
            string deleteCartQuery = "DELETE FROM CART WHERE CART_ID = :cartID";
            string conStr = @"DATA SOURCE=localhost:1521/XE; USER ID=MIAN123; PASSWORD=112233";

            using (OracleConnection conn = new OracleConnection(conStr))
            {
                try
                {
                    conn.Open();

                    // Start a transaction
                    using (OracleTransaction transaction = conn.BeginTransaction())
                    {
                        try
                        {
                            // Delete the product from the ORDERS table
                            using (OracleCommand deleteOrderCmd = new OracleCommand(deleteOrderQuery, conn))
                            {
                                deleteOrderCmd.Transaction = transaction;
                                deleteOrderCmd.Parameters.Add("cartID", OracleDbType.Int32).Value = cartID;
                                deleteOrderCmd.ExecuteNonQuery();
                            }

                            // Delete the product from the CART table
                            using (OracleCommand deleteCartCmd = new OracleCommand(deleteCartQuery, conn))
                            {
                                deleteCartCmd.Transaction = transaction;
                                deleteCartCmd.Parameters.Add("cartID", OracleDbType.Int32).Value = cartID;
                                deleteCartCmd.ExecuteNonQuery();
                            }

                            // Commit the transaction
                            transaction.Commit();
                            return true; // Indicate success
                        }
                        catch
                        {
                            // Rollback the transaction in case of any failure
                            transaction.Rollback();
                            throw;
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("An error occurred while deleting the product: " + ex.Message);
                    return false;
                }
            }
        }

    }
}
