﻿using Oracle.ManagedDataAccess.Client;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Form5 : Form
    {
        public Form5()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            
            string username = GlobalData.Username; // Retrieve username
            string password = GlobalData.Password; // Retrieve password
            string phoneNumber = textBox1.Text;
            string address = textBox2.Text;
            string email = textBox3.Text;

            // Validate input fields
            if (string.IsNullOrEmpty(phoneNumber) || string.IsNullOrEmpty(address) || string.IsNullOrEmpty(email))
            {
                MessageBox.Show("All fields are required.");
                return;
            }

            string query = "INSERT INTO Customer (USER_ID, USER_NAME, PASSWORD, PHONE_NUMBER, ADDRESS, EMAIL) " +
                           "VALUES (CUSTOMER_SEQ.NEXTVAL, :username, :password, :phoneNumber, :address, :email)";

            string connectionString = @"DATA SOURCE=localhost:1521/XE;USER ID=MIAN123;PASSWORD=112233";

            try
            {
                using (OracleConnection conn = new OracleConnection(connectionString))
                {
                    conn.Open();
                    using (OracleCommand cmd = new OracleCommand(query, conn))
                    {
                        cmd.Parameters.Add("username", OracleDbType.Varchar2).Value = username;
                        cmd.Parameters.Add("password", OracleDbType.Varchar2).Value = password;
                        cmd.Parameters.Add("phoneNumber", OracleDbType.Varchar2).Value = phoneNumber;
                        cmd.Parameters.Add("address", OracleDbType.Varchar2).Value = address;
                        cmd.Parameters.Add("email", OracleDbType.Varchar2).Value = email;

                        int rowsAffected = cmd.ExecuteNonQuery();
                        if (rowsAffected > 0)
                        {
                            MessageBox.Show("User registered successfully!");
                            this.Hide();
                            Form2 form2 = new Form2();
                            form2.ShowDialog();
                        }
                        else
                        {
                            MessageBox.Show("Registration failed. Please try again.");
                        }
                    }
                }
            }
            catch (OracleException ex)
            {
                MessageBox.Show($"Database error: {ex.Message}");
            }
            catch (Exception ex)
            {
                MessageBox.Show($"An error occurred: {ex.Message}");
            }

        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form4 form4 = new Form4();
            form4.ShowDialog();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }

        private void Form5_Load(object sender, EventArgs e)
        {

        }
    }
}
