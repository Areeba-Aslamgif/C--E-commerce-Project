﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Oracle.ManagedDataAccess.Client;

namespace WindowsFormsApp1
{
    public partial class Form26 : Form
    {
        public Form26()
        {
            InitializeComponent();
        }

        private void textBox4_TextChanged(object sender, EventArgs e)
        {
            // For password input
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            // For phone number input
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {
            // For address input
        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {
            // For email input
        }

        private void button1_Click(object sender, EventArgs e)
        {
            // Submit button logic
            UpdateCustomerData();
        }

        private void UpdateCustomerData()
        {
            int userID = SessionManager.LoggedInUserID.Value; // Assuming user ID is stored in a session manager
            string conStr = @"DATA SOURCE=localhost:1521/XE; USER ID=MIAN123; PASSWORD=112233";

            string newPassword = textBox4.Text.Trim();
            string newPhoneNumber = textBox1.Text.Trim();
            string newAddress = textBox2.Text.Trim();
            string newEmail = textBox3.Text.Trim();

            try
            {
                using (OracleConnection conn = new OracleConnection(conStr))
                {
                    conn.Open();

                    // Retrieve current data for the user
                    string query = "SELECT PASSWORD, PHONE_NUMBER, ADDRESS, EMAIL FROM CUSTOMER WHERE USER_ID = :userID";
                    OracleCommand cmd = new OracleCommand(query, conn);
                    cmd.Parameters.Add("userID", OracleDbType.Int32).Value = userID;

                    using (OracleDataReader reader = cmd.ExecuteReader())
                    {
                        if (reader.Read())
                        {
                            // Use current values if fields are left empty
                            string currentPassword = reader["PASSWORD"].ToString();
                            string currentPhoneNumber = reader["PHONE_NUMBER"].ToString();
                            string currentAddress = reader["ADDRESS"].ToString();
                            string currentEmail = reader["EMAIL"].ToString();

                            newPassword = string.IsNullOrEmpty(newPassword) ? currentPassword : newPassword;
                            newPhoneNumber = string.IsNullOrEmpty(newPhoneNumber) ? currentPhoneNumber : newPhoneNumber;
                            newAddress = string.IsNullOrEmpty(newAddress) ? currentAddress : newAddress;
                            newEmail = string.IsNullOrEmpty(newEmail) ? currentEmail : newEmail;
                        }
                        else
                        {
                            MessageBox.Show("User data not found.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            return;
                        }
                    }

                    // Update only the provided fields
                    string updateQuery = @"
                        UPDATE CUSTOMER 
                        SET PASSWORD = :password, 
                            PHONE_NUMBER = :phoneNumber, 
                            ADDRESS = :address, 
                            EMAIL = :email 
                        WHERE USER_ID = :userID";

                    OracleCommand updateCmd = new OracleCommand(updateQuery, conn);
                    updateCmd.Parameters.Add("password", OracleDbType.Varchar2).Value = newPassword;
                    updateCmd.Parameters.Add("phoneNumber", OracleDbType.Varchar2).Value = newPhoneNumber;
                    updateCmd.Parameters.Add("address", OracleDbType.Varchar2).Value = newAddress;
                    updateCmd.Parameters.Add("email", OracleDbType.Varchar2).Value = newEmail;
                    updateCmd.Parameters.Add("userID", OracleDbType.Int32).Value = userID;

                    int rowsUpdated = updateCmd.ExecuteNonQuery();

                    if (rowsUpdated > 0)
                    {
                        MessageBox.Show("Customer data updated successfully.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        this.Close();
                    }
                    else
                    {
                        MessageBox.Show("Failed to update customer data.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"An error occurred: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form6 form6 = new Form6();
            form6.ShowDialog();
        }

        private void Form26_Load(object sender, EventArgs e)
        {

        }
    }
}
