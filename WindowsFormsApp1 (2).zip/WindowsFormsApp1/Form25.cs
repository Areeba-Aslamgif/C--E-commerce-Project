﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Oracle.ManagedDataAccess.Client;  // Ensure you have the Oracle client

namespace WindowsFormsApp1
{
    public partial class Form25 : Form
    {
        public Form25()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form2 form2 = new Form2();
            form2.ShowDialog();
        }

        private void Form25_Load(object sender, EventArgs e)
        {
            // Fetch orders from the database when the form loads
            LoadOrders();
        }

        private void LoadOrders()
        {
            string query = "SELECT ORDER_ID, USER_ID, CART_ID, ORDER_DATE, STATUS, TOTAL_PRICE, PAYMENT_METHOD FROM ORDERS";

            string conStr = @"DATA SOURCE=localhost:1521/XE; USER ID=MIAN123; PASSWORD=112233"; // Replace with your connection string

            using (OracleConnection conn = new OracleConnection(conStr))
            {
                try
                {
                    conn.Open();
                    OracleDataAdapter dataAdapter = new OracleDataAdapter(query, conn);
                    DataTable dataTable = new DataTable();
                    dataAdapter.Fill(dataTable);

                    // Bind the fetched data to the DataGridView
                    dataGridView1.DataSource = dataTable;
                }
                catch (Exception ex)
                {
                    MessageBox.Show("An error occurred while fetching orders: " + ex.Message);
                }
            }
        }


        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        // Process the selected order
        private void button1_Click(object sender, EventArgs e)
        {
            if (dataGridView1.SelectedRows.Count > 0)
            {
                // Get the selected order and cart IDs
                DataGridViewRow selectedRow = dataGridView1.SelectedRows[0];
                int selectedOrderID = Convert.ToInt32(selectedRow.Cells["ORDER_ID"].Value);
                int selectedCartID = Convert.ToInt32(selectedRow.Cells["CART_ID"].Value);

                if (selectedOrderID > 0 && selectedCartID > 0)
                {
                    UpdateOrderStatus(selectedOrderID, "Processed");
                    UpdateCartStatus(selectedCartID, "Processed");

                    // Refresh the DataGridView
                    LoadOrders();
                    MessageBox.Show("Order processed successfully.");
                }
                else
                {
                    MessageBox.Show("Invalid selection.");
                }
            }
            else
            {
                MessageBox.Show("Please select an order.");
            }
        }

        // Ship the selected order
        private void button2_Click(object sender, EventArgs e)
        {
            if (dataGridView1.SelectedRows.Count > 0)
            {
                DataGridViewRow selectedRow = dataGridView1.SelectedRows[0];
                int selectedOrderID = Convert.ToInt32(selectedRow.Cells["ORDER_ID"].Value);
                int selectedCartID = Convert.ToInt32(selectedRow.Cells["CART_ID"].Value);

                if (selectedOrderID > 0 && selectedCartID > 0)
                {
                    UpdateOrderStatus(selectedOrderID, "Shipped");
                    UpdateCartStatus(selectedCartID, "Shipped");

                    // Refresh the DataGridView
                    LoadOrders();
                    MessageBox.Show("Order shipped successfully.");
                }
                else
                {
                    MessageBox.Show("Invalid selection.");
                }
            }
            else
            {
                MessageBox.Show("Please select an order.");
            }
        }

        // Mark the selected order as delivered
        private void button4_Click(object sender, EventArgs e)
        {
            if (dataGridView1.SelectedRows.Count > 0)
            {
                DataGridViewRow selectedRow = dataGridView1.SelectedRows[0];
                int selectedOrderID = Convert.ToInt32(selectedRow.Cells["ORDER_ID"].Value);
                int selectedCartID = Convert.ToInt32(selectedRow.Cells["CART_ID"].Value);

                if (selectedOrderID > 0 && selectedCartID > 0)
                {
                    UpdateOrderStatus(selectedOrderID, "Delivered");
                    UpdateCartStatus(selectedCartID, "Delivered");

                    // Refresh the DataGridView
                    LoadOrders();
                    MessageBox.Show("Order delivered successfully.");
                }
                else
                {
                    MessageBox.Show("Invalid selection.");
                }
            }
            else
            {
                MessageBox.Show("Please select an order.");
            }
        }

        // Cancel the selected order
        private void button3_Click(object sender, EventArgs e)
        {
            if (dataGridView1.SelectedRows.Count > 0)
            {
                DataGridViewRow selectedRow = dataGridView1.SelectedRows[0];
                int selectedOrderID = Convert.ToInt32(selectedRow.Cells["ORDER_ID"].Value);
                int selectedCartID = Convert.ToInt32(selectedRow.Cells["CART_ID"].Value);

                if (selectedOrderID > 0 && selectedCartID > 0)
                {
                    UpdateOrderStatus(selectedOrderID, "Canceled");
                    UpdateCartStatus(selectedCartID, "Canceled");

                    // Refresh the DataGridView
                    LoadOrders();
                    MessageBox.Show("Order canceled successfully.");
                }
                else
                {
                    MessageBox.Show("Invalid selection.");
                }
            }
            else
            {
                MessageBox.Show("Please select an order.");
            }
        }

        // Update the status of the order in the ORDERS table
        private void UpdateOrderStatus(int orderId, string status)
        {
            string query = "UPDATE ORDERS SET STATUS = :status WHERE ORDER_ID = :orderId";

            string conStr = @"DATA SOURCE=localhost:1521/XE; USER ID=MIAN123; PASSWORD=112233";  // Your DB connection string

            using (OracleConnection conn = new OracleConnection(conStr))
            {
                try
                {
                    conn.Open();
                    using (OracleCommand cmd = new OracleCommand(query, conn))
                    {
                        cmd.Parameters.Add("status", OracleDbType.Varchar2).Value = status;
                        cmd.Parameters.Add("orderId", OracleDbType.Int32).Value = orderId;

                        int rowsAffected = cmd.ExecuteNonQuery();
                        if (rowsAffected > 0)
                        {
                            MessageBox.Show($"Order {status.ToLower()} successfully.");
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error updating order status: " + ex.Message);
                }
            }
        }

        // Update the status of the cart in the CART table
        private void UpdateCartStatus(int cartId, string status)
        {
            string query = "UPDATE CART SET STATUS = :status WHERE CART_ID = :cartId";

            string conStr = @"DATA SOURCE=localhost:1521/XE; USER ID=MIAN123; PASSWORD=112233";  // Your DB connection string

            using (OracleConnection conn = new OracleConnection(conStr))
            {
                try
                {
                    conn.Open();
                    using (OracleCommand cmd = new OracleCommand(query, conn))
                    {
                        cmd.Parameters.Add("status", OracleDbType.Varchar2).Value = status;
                        cmd.Parameters.Add("cartId", OracleDbType.Int32).Value = cartId;

                        int rowsAffected = cmd.ExecuteNonQuery();
                        if (rowsAffected > 0)
                        {
                            MessageBox.Show($"Cart status updated to {status.ToLower()}.");
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error updating cart status: " + ex.Message);
                }
            }
        }
    }
}