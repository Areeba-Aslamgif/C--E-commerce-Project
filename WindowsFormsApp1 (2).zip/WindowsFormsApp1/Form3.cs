﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;
using Oracle.ManagedDataAccess.Client;
namespace WindowsFormsApp1
{
    public partial class Form3 : Form
    {
       
        public Form3()
        {
            InitializeComponent();
        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox1.Checked)
            {
                textBox2.UseSystemPasswordChar = false;
            }
            else
            {
                textBox2.UseSystemPasswordChar = true;
            }
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            string name = textBox1.Text;
            string password = textBox2.Text;

            if (name == "admin" && password == "admin")
            {
                // Navigate to Form25
                this.Hide();
                Form25 form25 = new Form25();
                form25.ShowDialog();
            }
            else
            {
                if (string.IsNullOrEmpty(name) || string.IsNullOrEmpty(password))
                {
                    MessageBox.Show("Please fill in all fields");
                    return;
                }

                bool isAuth = authUser(name, password);

                if (isAuth)
                {
                    // Assuming you have user ID after successful authentication
                    int userID = GetUserID(name); // Get user ID from the database
                    string userName = name; // You can also get the user name from the database if needed

                    // Store the login details in SessionManager
                    SessionManager.Login(userID, userName);

                    MessageBox.Show("Login successful");

                    // Navigate to Form6 or any other form you want after login
                    this.Hide();
                    Form6 form6 = new Form6();
                    form6.ShowDialog();
                }
                else
                {
                    MessageBox.Show("Invalid username or password");
                }
            }

        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form2 form2 = new Form2();
            form2.ShowDialog();
        }
        private bool authUser(string name, string password)
        {
            try
            {
                string query = "SELECT user_id, password FROM Customer WHERE UPPER(user_name) = UPPER(:name)";
                string conStr = @"DATA SOURCE=localhost:1521/XE; USER ID=MIAN123; PASSWORD=112233";

                using (OracleConnection conn = new OracleConnection(conStr))
                {
                    conn.Open();
                    using (OracleCommand cmd = new OracleCommand(query, conn))
                    {
                        cmd.Parameters.Add("name", OracleDbType.Varchar2).Value = name;

                        using (OracleDataReader reader = cmd.ExecuteReader())
                        {
                            if (reader.Read())
                            {
                                string dbPassword = reader.GetString(1); // Password from DB
                                // You should hash the input password and compare it with the stored password in a real scenario
                                if (dbPassword == password)
                                {
                                    // User authenticated, return true
                                    return true;
                                }
                                else
                                {
                                    MessageBox.Show("Invalid password.");
                                }
                            }
                            else
                            {
                                MessageBox.Show("User not found!");
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
            return false;
        }
        private int GetUserID(string username)
        {
            // Method to retrieve the user ID from the database after authentication
            // You can modify it according to your specific requirements

            try
            {
                string query = "SELECT user_id FROM Customer WHERE UPPER(user_name) = UPPER(:name)";
                string conStr = @"DATA SOURCE=localhost:1521/XE; USER ID=MIAN123; PASSWORD=112233";

                using (OracleConnection conn = new OracleConnection(conStr))
                {
                    conn.Open();
                    using (OracleCommand cmd = new OracleCommand(query, conn))
                    {
                        cmd.Parameters.Add("name", OracleDbType.Varchar2).Value = username;

                        object result = cmd.ExecuteScalar();
                        if (result != null)
                        {
                            return Convert.ToInt32(result);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error retrieving user ID: " + ex.Message);
            }
            return -1; // Return -1 if user ID cannot be retrieved
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void Form3_Load(object sender, EventArgs e)
        {

        }
    }
}
