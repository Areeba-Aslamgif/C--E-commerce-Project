﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WindowsFormsApp1
{
    public static class GlobalData
    {
        public static string Username { get; set; }
        public static string Password { get; set; }
    }

}
